package Commands;

public interface ICommands {
    boolean execute(String argument);
    boolean execute();
}

//The interface for execution of commands

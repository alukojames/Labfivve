package Data;

public class Coordinates {
    private int x; //Максимальное значение поля: 922
    private double y; //Максимальное значение поля: 922

    public Coordinates(int x, double y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public double getY() {
        return y;
    }

}

package Data;

public enum UnitOfMeasure {
    KILOGRAMS,
    METERS,
    SQUARE_METERS,
    GRAMS
}


